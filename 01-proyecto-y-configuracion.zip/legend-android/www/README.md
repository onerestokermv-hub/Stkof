# Legend of Presos — El escape de Puente Grande

Juego de pelea 2D inspirado en KOF 2002, ambientado en el Reclusorio Preventivo de Puente Grande, Jalisco. Conserva el motor JavaScript/HTML con PixiJS v8, sin paso de compilación, y una simulación determinista a 60 pasos por segundo. Este documento describe el estado de este paquete; no es un historial de builds.

> **Para continuar el trabajo (otro chat o persona): lee primero `CONTINUAR_AQUI.md`.** Estado detallado en `docs/PROJECT_STATUS.md`; cambios en `docs/CHANGELOG.md`.

## Estado de la entrega

- **Esta entrega (2026-10-30):** nombres confirmados sobre la base 2026-10-27c y auditoría técnica de Omar Harfuch. El Cachorro (`personaje_08`), Toker (`diego_cancha`), Gordo Ali (`pocheche`) y Omar Harfuch (`pocheche_tijeras`) ya aparecen con sus nombres aprobados; Regente conserva su nombre y papel de abogado; Cochi Bombis y El Gordo Tacos no se alteraron. Los IDs, arte y datos de combate permanecen intactos. El ZIP conserva el manifiesto y la extracción limpia; el juego no se declara terminado.
- Se conservan los combos verificados (`qa/COMBOS_VERIFICADOS.md`), cancelación a súper estilo KOF 2002, orden visual de ataques, **Mateo con el arte de El Sable**, golpes de **Valentina** y **Diego**, y **El Aedillo** PROVISIONAL. No hubo cambios de combate, arte, CSS ni datos generados en esta fase.
- Canon vigente: **Tobi — El Sobrino** es el protagonista; **La Tapia** conserva el id interno `calavera`. No se inventaron otros nombres ni parentescos.
- El selector tiene un diseño compacto futurista: negro predominante, acentos rojo/amarillo neón, tarjetas apiladas y deslizables, datos del peleador y energía verde.
- La prueba dirigida `qa/test_canonical_names_orientation.py` pasó en Chromium: 18 verificaciones de nombres y 488 cuadros/lados/tamaños, con espejo técnico según `facing`, `MatchState` intacto y 0 errores JS/HTTP. La inversión artística concreta reportada para Omar no se reprodujo; no se corrigieron píxeles por suposición. Ver `qa/omar_orientation/names_render_results.json`.
- Arcade 1v1 y 3v3, Equipos 3v3, Torneo 1v1/3v3, Versus, Entrenamiento y Opciones se conservan como rutas del juego.
- El atlas original de Nina KOF está en `assets/combat/nina_kof/` sin editar. Se añadieron borradores generados de carrera, agarre frontal y victoria, pero no se conectaron al runtime. Nina conserva su entrada de roster `status: "needs_data"`; **no es seleccionable ni runtime-ready**. Faltan revisión/aprobación de arte, mapeo compatible con el loader y datos de combate. Detalles en `assets/combat/nina_kof/INTEGRACION_NINA_KOF.md`.
- La prueba en teléfono Android real sigue pendiente; la evidencia disponible es Chromium/Playwright en este entorno.

## Cómo ejecutar

Desde la carpeta que contiene `game.html`:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

Abre `http://127.0.0.1:8000/game.html`. La entrada de desarrollo para un combate directo es `http://127.0.0.1:8000/combate.html?p1=tobi&p2=calavera&stage=penal_puente_grande`. No abras los HTML con `file://`: el juego carga JSON y recursos por HTTP.

### Integridad y empaquetado

Desde una extracción limpia, `sha256sum -c MANIFEST_SHA256.txt` debe comprobar todos los archivos declarados. El manifiesto se excluye a sí mismo para evitar una autorreferencia imposible.

```bash
sha256sum -c MANIFEST_SHA256.txt
python3 qa/test_regression_runner.py   # fixtures del arnés, NO pruebas del juego
python3 qa/test_package_project.py     # fixture del empaquetador
tools/run_regression.sh qa/runs/mi_prueba
python3 tools/package_project.py /ruta/fuera/del/proyecto/LegendOfPresos.zip
```

La regresión inicia su propio servidor: detén antes el servidor manual en 8000 o configura otro `PG_PORT` disponible (8765 está reservado para la prueba de Nina). Devuelve 1 si falla un paso y 2 si no puede iniciar el servidor; no basta con ver la última línea. Las pruebas escriben evidencia nueva y cambian el manifiesto del paquete recibido: para volver a empaquetar, el script lo regenera. El empaquetador no elimina logs, fuentes, documentación ni herramientas y conserva los nombres con ñ. No genera ni compila APK.

## Controles

| Acción | Jugador 1 | Jugador 2 | Mando |
|---|---|---|---|
| Mover / agacharse | `A` `D` / `S` | `←` `→` / `↓` | Cruceta o stick |
| Saltar | `W` | `↑` | Arriba |
| Puño / patada | `J` / `K` | `1` / `2` | A / B |
| Especial / súper | `L` / `U` | `3` / `0` | X / Y |
| Guardia | `Shift` | `/` | Gatillos |

Las teclas se pueden reasignar en **Opciones → Teclas**. En pantalla táctil se muestran joystick izquierdo y botones de combate a la derecha. `Enter` confirma; `Esc` vuelve o pausa; `F` muestra cajas de golpe; `M` silencia. En Entrenamiento: `G` cambia el comportamiento del maniquí, `B` alterna la barra infinita y `R` reinicia posiciones; los ajustes también están en la pausa.

Técnicas documentadas por el motor: adelante dos veces = carrera; atrás dos veces = retroceso; arriba = salto corto y abajo→arriba = salto alto; Puño+Patada = rodada o recuperación según el momento; Guardia+Puño = agarre/escape; Puño+Patada bloqueando = cancelación de guardia; Puño+Especial = MAX. Consulta **Comandos** para las entradas de cada personaje.

## Modos

- **Arcade:** duelo 1v1 o campaña 3v3 contra CPU.
- **Equipos:** selección de tres luchadores por lado; CPU o jugador 2, orden de entrada y HUD de equipo.
- **Torneo:** escalera individual o por equipos.
- **Versus:** dos jugadores en teclado o mandos.
- **Entrenamiento:** maniquí configurable, ventaja de frames, sin K.O. y barra/reloj según sus opciones.
- **Opciones:** audio, partida, pantalla y remapeo de teclas.

Los E2E verifican el inicio de los modos señalados; no implican que se hayan completado todas las rondas, resultados o finales de campaña.

## Estructura

```text
game.html, combate.html       Entradas del juego completo y combate de desarrollo
engine/pg_sim.js              Simulación determinista y MatchState serializable
engine/pg_game.js             Orquestación, bucle fijo, equipos y carga
engine/pg_frontend.js         Menús, selector, campañas y opciones
engine/pg_render.js            Render de MatchState; no escribe en la simulación
engine/pg_loader.js            Carga y liberación de atlas, FX y escenarios
engine/pg_input.js             Teclado, gamepad y táctil (módulos relacionados)
engine/pg_audio.js             Web Audio, pool de SFX y sintetizador alternativo
data/config.json              Valores de combate configurables y notas _doc
data/roster.json              Elenco y perfiles
data/stages.json              Datos de escenarios
assets/combat/                 Definiciones, atlas y metadatos de luchadores
assets/stages/                 Fondos y capas de escenario
assets/fx/                    Recursos de efectos
assets/audio/                 Narración y medios de audio disponibles
styles/                       Estilos del juego y de combate
tools/                         Validadores, generadores y pruebas de simulación
qa/                            E2E, mediciones, capturas y logs de validación
docs/                          Estado del proyecto, changelog y auditoría inicial
sources/                       Arte original de las entregas (con SHA256SUMS); los generadores leen de aquí
manifest.webmanifest, sw.js    Instalación PWA y caché offline
```

## Añadir contenido

**Luchador:** lo más directo hoy es una spec `tools/specs/<id>_seated.json` y `python3 tools/build_seated_char.py <id>` (atlas sentado con el pie en la línea base, cajas de golpe medidas del arte, char.json GENERADO; ejemplos: `mateo`, `el_aedillo`); si la hoja trae el fondo de tablero pintado, recórtala con `tools/cut_painted_checker.py` (ver `tools/build_diego_hojas.py`). Comprueba los combos con `node tools/combo_check.js <id>` y agrégalo a `tools/specs/combo_expect.json`. A mano: crea `assets/combat/<id>/<id>.char.json` con clips, atlas declarados, referencias explícitas a cuadros, movimientos y datos de combate; agrega el personaje a `data/roster.json` y a los manifiestos que consume el loader (`data/runtime_manifest.json` y referencias relacionadas). Añade retrato si lo requiere la UI. No infieras cuadros, tiempos o hitboxes. Un personaje que use el esquema existente no debería exigir cambios al motor; una mecánica nueva sí puede requerirlos. Comprueba con `python3 tools/validate_data.py` y las pruebas de simulación/E2E pertinentes.

**Escenario:** declara el escenario en `data/stages.json`, incluye sus capas en `assets/stages/` y completa las medidas/datos requeridos por el esquema (arte, tema, luces y efectos). Usa los generadores de `tools/` cuando aplique y valida con `python3 tools/validate_data.py`.

**Nina KOF:** el paquete fuente contiene cuatro hojas PNG de 480×480, celdas 4×4 de 120×120 y pivote inferior-centro; siguen intactas. Además, `assets/combat/nina_kof/generated_drafts/` contiene tres atlas experimentales de carrera, agarre frontal y victoria, 2×2 celdas de 120×120. Estos son arte generado provisional, no han sido aprobados ni conectados a clips runtime. `nina_kof.char.json` separa las candidaturas fuente y los `generatedFrameDrafts`; no es aún el esquema de clips que consume el motor. Nina está en `needs_data` y no aparece en selección. Para activarla faltan revisión y aprobación de arte, mapeo de clips/duraciones, movimientos, inputs, hitboxes, parámetros de combate y nombre/perfil aprobados.

## Configuración, esquina y game feel

`data/config.json` centraliza la física, tiempos, cámara, stun, guardia, equipos y otros valores de diseño, con `_doc`. La presión de esquina ya está configurada en `corner`: `enabled`, `pushMul` y `threshold`; la simulación prueba empuje por golpe/bloqueo cuerpo a cuerpo y el apagado de la regla. Se conservaron sus valores actuales.

Los valores de recuperación de equipos (`team.recoverMax`), K.O. (`timing.koFreeze`), mareo (`stun.dizzyFrames`) y cámara (`camera`) permanecen configurables; no se ajustaron jugando en esta pasada. Los datos de golpes y FX viven en `data/*.json`. No se verificó automáticamente cada movimiento para asegurar su chispa y sonido particulares. El escalado visual actual se conserva; no se añadió una opción `render.scaling` desconectada del render.

## Audio

El juego busca archivos reales de `assets/audio/`; si faltan o no se decodifican, cae al sintetizador procedural. `audio.sfxVoiceCount=8` se lee de `data/config.json`; los canales de ganancia se reutilizan. Web Audio crea una fuente `AudioBufferSourceNode` por reproducción porque es de un solo uso; no se midió latencia física. El paquete incluye `intro_narration_es_mx.wav`, pero no los SFX de combate ni las pistas musicales. Los nombres esperados, formatos y cómo regenerar `audio-index.json` están en `assets/audio/LEEME.txt`.

## PWA y Android

El manifiesto y el service worker permiten instalar la app y jugar sin conexión tras completar la primera precarga. En Chromium se comprobó una caché de 327 entradas, incluyendo 283 rutas dinámicas generadas desde datos (regresión del 2026-10-26); al desconectar la red, recargar y abrir Arcade se inició un combate. `sw.js` y `public/sw.js` son idénticos. Esto no sustituye la prueba de instalación ni el chequeo de memoria en un teléfono real.

Pasos para la prueba física:

1. Descomprime este ZIP en el teléfono e instala/abre Termux.
2. En Termux, entra a la carpeta donde está `game.html` y ejecuta `python3 -m http.server 8000 --bind 127.0.0.1`.
3. En Chrome del mismo teléfono, abre `http://127.0.0.1:8000/game.html` y espera a que cargue el menú y termine la primera precarga.
4. En el menú de Chrome elige **Instalar aplicación** o **Agregar a pantalla principal**. Abre el icono instalado y verifica pantalla completa y orientación horizontal.
5. Prueba Arcade 1v1, Arcade 3v3, Equipos, Torneo, Versus y Entrenamiento con los dedos; revisa que el joystick, botones, HUD y pausa sean alcanzables.
6. Activa modo avión, cierra por completo y vuelve a abrir la app. Comprueba que el menú aparece y se inicia una pelea Arcade. Si falla, registra modelo del teléfono, Android/Chrome y el primer mensaje visible.

## Decisiones tomadas por defecto

- Ataque CD y normales agachados no están en esta entrega: faltan cuadros de animación y botón. No se reutilizó otra animación ni se inventó un botón.
- Para las poses de victoria dudosas de Cochibomba, Diego Cancha, Carmesí y Gasu, se usa idle marcado `TODO: VERIFICAR`; Personaje 08 sigue sin pose propia. Valentina ya tiene victoria propia (paquete "Nadia", 2026-10-26).
- El mareo conserva el vaivén y las estrellas del render.
- En los ocho personajes cuyos nombres de movimiento no están confirmados se conserva el ID de dato y se muestra **Especial 1/2/3**, marcado `TODO: VERIFICAR`.
- El Gordo Tacos, foco+encendedor y catálogo 135 quedan tal como están; no se inventaron nombres ni diseños.
- Se mantuvo el escalado visual actual. El config no tiene una opción funcional `render.scaling`; añadir solo un campo sin conexión al render sería engañoso.
- No se tocaron los valores de diseño que requieren pruebas jugando: `team.recoverMax`, `timing.koFreeze`, `stun.dizzyFrames` y `camera`; siguen declarados en `data/config.json`.
- Los sprites, retratos y fondos fuente permanecen intactos. A solicitud del usuario se extrajeron por contorno alfa los 64 cuadros fuente de Nina y 12 cuadros provisionales previos; los derivados están en `assets/combat/nina_kof/processed_contours/`. Los tres movimientos generados siguen marcados como borrador. Los iconos PWA no alteran el arte del juego.

## Pendientes que dependen de ti

- **El Aedillo:** entró como PROVISIONAL (dejaste la decisión abierta). Confirma si se queda, su nombre/identidad y si lo quieres en las campañas.
- **Hombre de bola y cadena:** personaje nuevo; faltan sus hojas de caminar, salto, recibir golpe, caídas y victoria, y su nombre (`sources/candidatos/bola_y_cadena/LEEME.md`).
- **Mateo:** su alias de expediente "Puños de brasa" ya no cuadra con la espada de El Sable.
- **Nina KOF:** el mapeo de arte por contorno y los atlas compatibles con `PGLoader` están en `assets/combat/nina_kof/nina_kof_contour_runtime_draft.char.json`; 18 clips candidatos cargan en Chromium. Nina conserva `status: "needs_data"` porque faltan `renderScale` aprobado, FPS/hold revisados, `moves` e `inputs`, hitboxes/frames de impacto, daño, stun, pushback, hitstop, FX/cancelaciones y aprobación de nombres/perfil. Tampoco hay cuadros de ataques aéreos, por lo que no se reutilizaron ataques de pie. No cambies el roster a `playable` hasta completar esos datos y validar el combate.
- **CD y normales agachados:** hojas/frames de animación y metadatos de coordenadas/duración para cada personaje correspondiente, más la decisión de botón si se habilita CD. Sin ese arte no deben activarse.
- **Poses de victoria:** arte/frames y mapeo `victory_pose` en cada `<id>.char.json` de la lista anterior; Personaje 08 también necesita una pose si debe dejar de usar su estado actual.
- **Nombres de movimientos:** nombres canónicos asociados a los IDs de los ocho `<id>.char.json`; se conservan los IDs de datos y solo falta sustituir las etiquetas genéricas.
- **Audio real:** medios con los nombres exactos de `assets/audio/LEEME.txt`. WAV, OGG Vorbis y MP3 se admiten; WAV PCM de 16 bits (44.1/48 kHz; mono SFX, estéreo música) es la recomendación del proyecto. **Nota:** los 22 WAV del paquete Android NO vienen en este ZIP (solo `intro_narration_es_mx.wav`); adjúntalos al chat para integrarlos. Mientras tanto el motor usa el sintetizador procedural.
- **Proyecto Android:** este ZIP NO incluye la carpeta `ANDROID/` (gradle/manifest). Para sincronizar el build web y empaquetar, adjunta el proyecto Android al chat.
- **Ajustes de diseño:** valores deseados para `team.recoverMax`, `timing.koFreeze`, `stun.dizzyFrames` y `camera`, tras probarlos jugando. No hace falta editar el motor; actualizar los valores en `data/config.json` y volver a validar.
- **Validación física:** ejecutar los seis pasos Android anteriores. El ZIP no se ha probado en hardware real.

## Pruebas y evidencia incluida

Desde la extracción limpia del ZIP final se verificaron:

- **Fase 2026-10-27 (d), evidencia nueva:** regresiones de línea base y posterior `qa/runs/2026-10-27_inicio_d/summary.tsv` / `qa/runs/2026-10-27_entrega_d/summary.tsv`, ambas **20/20 rc=0**, código global posterior 0; `test_sim` 197 OK con salida exacta anterior; datos 0 errores/0 avisos. Pruebas aisladas de herramientas: arnés 7/7, empaquetador 3/3. Estas dos regresiones se ejecutaron en la copia de trabajo; el ZIP entregado se verifica aparte mediante su manifiesto y extracción limpia.
- Regresión completa de esta entrega (consolidación 2026-10-27): `qa/runs/2026-10-27_consolida/summary.tsv` → **20/20 en rc=0**. Antes el paso `10_audit_all_atlases` iba en rc=1 por 28 falsos positivos de `nina_kof`; ahora `tools/audit_all_atlases.py` lee `coordsFile` (como el loader) y queda en rc=0 sin ocultar problemas. Entrega previa: `qa/runs/2026-10-26_entrega/summary.tsv`. Detalle en `docs/PROJECT_STATUS.md`.
- `node tools/test_sim.js`: **197 comprobaciones OK** (`TODO OK`). La consolidación 2026-10-27 no tocó el motor: huella determinista idéntica.
- `node tools/combo_check.js --strict`: **COMBOS OK** (8 personajes vigilados; excepciones de diseño en `tools/specs/combo_expect.json`).
- `python3 tools/validate_data.py`: **0 errores, 0 avisos**.
- `python3 tools/sync_defaults.py --check`: **igual**.
- `python3 tools/build_offline_assets.py --check`: **igual**.
- `PG_URL=http://127.0.0.1:8001/game.html python3 qa/test_canonical_names_orientation.py`: **PASS**, 18 nombres y 488 cuadros/lados/tamaños; límite documentado: no prueba la dirección semántica dibujada de cada pose.
- `python3 tools/process_nina_contours.py` y `python3 tools/validate_nina_contours.py`: 76 crops pixel-exactos, hashes de atlas fuente intactos, 19 grupos y anclas/rectángulos verificados; `low_kick` queda excluido del runtime.
- `python3 qa/test_nina_contour_loader.py`: Chromium carga con el `PGLoader` real 18 clips / 72 texturas de Nina, sin errores de consola. Prueba el loader, no el selector ni combate jugable.
- Sintaxis de los módulos principales y de ambos service workers; `sw.js` raíz/público idénticos.

Pruebas reales de UI con Playwright/Chromium, clics/teclas y capturas en `qa/`:

- `qa/test_selector_neon.py`: menú y selectores; cuatro tamaños **360×800, 412×915, 800×360 y 1280×720**; las 29 cartas de Arcade (30 en Versus, Equipos, Torneo y Entrenamiento: en Arcade no se elige a Garravas, el jefe final) y sus energías cargan desde datos sin overflow. El E2E verifica por UI que `nina_kof` no aparece en Arcade, Equipos, Torneo, Versus ni Entrenamiento mientras el roster tenga `needs_data`. Rueda probada en los tamaños; gesto táctil emulado en 360×800. Errores de aplicación: 0. Chromium emitió cuatro mensajes filtrados `GL Driver Message` / `GPU stall due to ReadPixels` en 360×800 (driver WebGL del entorno); cualquier otro warning/error falla el test.
- `qa/test_modes_launch.py`: inicio por UI de Arcade 1v1, Equipos 3v3, Versus y Entrenamiento; se enviaron acciones de teclado y se guardaron capturas.
- `qa/test_team_campaigns.py`: inicio por UI de la primera pelea de Arcade 3v3 y Torneo 3v3; consola limpia y pool SFX configurado 8/8.
- `qa/test_pwa_offline.py`: 327 entradas en caché (`legend-of-presos-v6`), red desconectada, recarga y combate Arcade iniciado offline.
- `qa/measure_3v3_memory.py`: equipo completo de seis IDs cargado por UI (personaje_08, wasirris, valentina_niebla contra regente, tobi, morado); 38 imágenes cacheadas (incluye escenario/FX; Valentina carga ahora 2 atlas más: energía y victoria), heap JS **13,234,583 B / 12.62 MiB**; CDP **11,011,512 B / 10.50 MiB**; atlas comprimidos **8,441,849 B**; estimación RGBA8 **154,516,896 B / 147.36 MiB**. Es una estimación de texturas decodificadas, **no una lectura de VRAM**; el heap varía entre sesiones.

El motor presenta pantalla de carga mientras precarga el combate y libera texturas que ya no se usan entre combates. No se redujeron dimensiones ni se modificó el arte de personajes. La estimación RGBA8 aún deja un riesgo que debe evaluarse en teléfonos de gama baja. La salida consolidada está en `qa/FINAL_VALIDATION.log`; la regresión adicional de Arcade 1v1 está en `qa/FINAL_VALIDATION_ADDENDUM.txt`.
