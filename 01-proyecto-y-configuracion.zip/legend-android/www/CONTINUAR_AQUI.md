# CONTINUAR AQUÍ — Puente Grande: Legend of Presos

Punto de continuación guardado el **2026-10-30** (auditoría sobre el ZIP real 2026-10-27c; juego y arte conservados). Si eres un chat nuevo: lee este archivo completo antes de tocar código.
Después lee `docs/PROJECT_STATUS.md` (estado detallado) y `docs/CHANGELOG.md` (qué cambió y cuándo).

> **Última fase (d):** integridad y herramientas cerradas, no juego terminado. El ZIP 2026-10-27c tenía cuatro nombres de PNG de Nadia mal marcados en UTF-8; se repararon solo sus rutas, con hashes exactos. Todos los 1.153 hashes originales coinciden al interpretar correctamente el ZIP. Se corrigió `tools/run_regression.sh` para propagar fallos, no absorber sintaxis inválida y exigir su servidor propio; fixtures 7/7 PASS. Se añadió `tools/package_project.py` (nombres UTF-8, conserva logs, manifiesto completo y extracción limpia), con 3/3 pruebas. Regresión real antes/después: **20/20 rc=0 en ambas** (`qa/runs/2026-10-27_inicio_d/` y `qa/runs/2026-10-27_entrega_d/`). `test_sim` 197 OK, salida idéntica. No cambió motor/arte/CSS/datos. Informe: `docs/AUDIT_2026-10-27D.md`. `ANDROID/`, WAV, trama y prueba física siguen pendientes; ya se pidieron al usuario. **No hay APK compilado.**
>
> Al ejecutar la regresión, detén antes el servidor manual en 8000 o usa otro `PG_PORT` libre; 8765 está reservado para Nina. `sha256sum -c MANIFEST_SHA256.txt` verifica una extracción limpia. Ejecutar pruebas cambia las evidencias de QA: para reempaquetar, el script regenera el manifiesto.

> **Fase 2026-10-30:** se aplicaron los nombres confirmados: El Cachorro, Toker, Gordo Ali y Omar Harfuch; Regente conserva su nombre y papel de abogado; Cochi Bombis y El Gordo Tacos se conservan. `qa/test_canonical_names_orientation.py` pasó con 18 nombres y 488 cuadros/lados/tamaños. El espejo técnico del renderer y la inmutabilidad de `MatchState` están comprobados. La inversión artística concreta de Omar no se reprodujo: no se corrigió por suposición; hace falta captura/vídeo o mapa exacto de cuadros y acción para una corrección visual reproducible.

> **Consolidación 2026-10-27 (esta pasada):** la regresión completa quedó **20/20 en rc=0** (antes el paso 10 iba en rc=1).
> (1) `tools/audit_all_atlases.py` ahora lee `coordsFile` igual que `engine/pg_loader.js`: se fueron los 28 falsos
> positivos de `nina_kof` (atlas por contorno) sin ocultar nada — se verificó que esos cuadros sí tienen contenido en su
> rect de coords y se añadió un chequeo nuevo real `coords_out_of_bounds`. (2) Menú: el strip de los 8 escenarios **envuelve
> y entra completo con altura ≥600 px** (escritorio/tablet); en paisaje bajo (teléfono, altura <600) se conserva la fila
> única deslizable de siempre, sin robar altura a las fichas. Sin cambios de motor ni de datos de combate; huella determinista intacta.
> (3) **Fix de capas**: en `pemex_guadalajara`, `oxxo_guadalajara` y `penal_puente_grande` el piso (capa `foreground`)
> iba `target:"front"` y tapaba la mitad inferior de los peleadores; pasó a `target:"back"` en `data/stages.json`.
> Verificado renderizando el combate real (evidencia en `qa/stage_layers_fix/`). Son los únicos 3 escenarios con capa foreground.
> (4) **Historia + nombres**: la narrativa (intro/final/créditos en `engine/pg_frontend.js`) quedó consolidada con **Tobi** como
> protagonista explícito ("Tobi —el Sobrino—"); el guion ya usaba "el Sobrino". Renombres en `data/roster.json`: `tobi`.alias→
> **"El Sobrino"**, `calavera`.name→**"La Tapia"** (mujer; id intacto). Evidencia en `qa/historia_nombres/`.
> **PENDIENTE:** el usuario pidió renombrar más personajes pero solo dio esos dos; falta su lista para el resto (no inventar nombres).
>
> **OJO — material que NO vino en este ZIP** (bloquea dos pendientes grandes; pídelo al usuario y adjúntalo al chat):
> no existe la carpeta **`ANDROID/`** (sin gradle ni manifest) ni los **22 WAV** del paquete de audio (solo está
> `assets/audio/intro_narration_es_mx.wav`). Sin eso no se puede sincronizar el build Android (§5.3) ni integrar el audio real (§5.4).

## 1. Qué es esto

Juego de pelea 2D estilo KOF, JavaScript sin compilación + PixiJS v8, simulación determinista a 60 Hz,
personajes 100 % por datos (`assets/combat/<id>/<id>.char.json` + atlas). Se prueba en Android físico.
Este ZIP es el **proyecto completo actualizado** (no un parche): ábrelo y sigue trabajando sobre él.

## 2. Cómo arrancarlo y probarlo

```bash
# servidor local (el juego usa fetch: no abre con file://)
python3 -m http.server 8000 --bind 127.0.0.1      # luego abre http://127.0.0.1:8000/game.html
# combate directo:   http://127.0.0.1:8000/combate.html?p1=mateo&p2=diego_cancha   (F = cajas, P = IA on/off)

# pruebas rápidas
node tools/test_sim.js                  # simulación determinista (197 ok)
python3 tools/validate_data.py          # datos (0 errores, 0 avisos)
node tools/combo_check.js --strict      # combos verdaderos de los personajes vigilados (COMBOS OK)
node tools/combo_list.js mateo --md x.md   # combos que conectan completos, con entradas y daño

# regresión completa (20 pruebas, incluye E2E en Chromium con Playwright). Esperado desde 2026-10-27: TODO rc=0 (20/20).
# (antes 10_audit_all_atlases iba en rc=1 por 28 falsos positivos de nina_kof; ya corregido al leer coordsFile)
tools/run_regression.sh qa/runs/<fecha>   # busca Chromium solo; para forzar uno: PG_CHROMIUM=<ruta> antes del comando
```

`game.html` es la entrada real. `index.html` es un andamio Vite que NO arranca el juego.

## 3. Lo que se hizo en esta etapa (2026-10-25/26, todo verificado con pruebas)

1. **Combos de los últimos personajes, verificados por simulación** (`tools/combo_check.js`): cada ruta de `cancelInto` se prueba con todos los tiempos de entrada. Arreglos: palma de los jefes y de La Sofi 12 → 11 de arranque; a los especiales de La Sofi les faltaba la ventana de súper. Resultado en `qa/COMBOS_VERIFICADOS.md`; las 3 rutas que no combinan son de diseño (especial lento desde golpe débil) y están en `tools/specs/combo_expect.json`.
2. **Motor:** cancelación a súper KOF 2002 (normal → súper siempre; especial → súper solo en MAX; antes no existía). Golpe de comando (→+botón) ya no deja su "adelante" para que el siguiente ↓↘→ salga como DP. El que ataca se dibuja delante. El Arcade dice 6 combates (lee `data/campaigns.json`).
3. **Mateo = arte de El Sable** (decisión del usuario): atlas sentado generado con escala por cuadro calibrada, pie en la suela, piezas ajenas apartadas; 11 golpes (9 con espada, 2 patadas; el botón Patada en el suelo es la "Estocada a fondo"). El arte viejo quedó en `sources/mateo/guardia_azul/`.
4. **Valentina:** puño y patada con energía + victoria del paquete "Nadia" (decisión del usuario: "mételos igual").
5. **Diego:** jab, golpe fuerte (→+P), patada, patada deslizada (↓↙←+K, derriba) y uppercut (→↓↘+P, nuevo) desde las hojas del usuario (tablero pintado → `tools/cut_painted_checker.py`).
6. **El Aedillo** (nuevo, PROVISIONAL: el usuario dejó la decisión abierta): 42 de 81 figuras; poses a ojo porque los rótulos del paquete no coinciden con lo dibujado. Sin agarres.
7. **Hombre de bola y cadena:** el usuario dijo que es **personaje nuevo**; faltan sus hojas de caminar/daño/caídas → guardado como candidato en `sources/candidatos/bola_y_cadena/LEEME.md`.

## 4. Decisiones del usuario que siguen vigentes

- Jefes = **seleccionables provisionales**; Garravas sigue como jefe final del Arcade. El Aedillo también provisional.
- Movimientos sin cuadros propios = **desactivados** (nunca inventar poses).
- Mateo usa el arte de El Sable (nombre Mateo "El Alcaide"); los cuadros "Nadia" van en Valentina (Nadia no cambia).
- Se aceptan estilos de dibujo mezclados en un personaje (Valentina, Diego).
- `nina_kof` se queda en `needs_data`; la versión jugable es **La Sofi**.
- Forma de trabajar: directivas breves en español; **no pasar parches** (proyecto completo); juego **descompuesto en archivos**; se prueba en **Android físico**; las altas al elenco se confirman con el usuario.

## 5. Pendiente (en orden sugerido)

1. **Jugar en Android y ajustar:** Mateo (espada), Diego (golpes nuevos: ver si su tamaño cuadra con el atlas realista), Valentina, El Aedillo, y también jefes y La Sofi. Tiempos y daños son de DISEÑO (`TODO: VERIFICAR jugando`). Arte residual de Sofi algo grande en `launch_3`, `candy_star_2/3`, `festive_super_3/4`, `getup_1`.
2. **Preguntas al usuario:** identidad/nombre de El Aedillo (¿se queda?); nombre y hojas de movimiento del hombre de bola y cadena; alias de Mateo ("Puños de brasa" no cuadra con la espada).
3. **Sincronizar Android** (BLOQUEADO: `ANDROID/` no viene en este ZIP): cuando el usuario adjunte el proyecto Android, script reproducible que copie el build web a `ANDROID/app/src/main/assets` (excluir `qa/ tools/ docs/ sources/ src/ public/assets/aistudio`). **No cambiar `applicationId` ni la firma.** Aquí no hay SDK de Android: **nunca afirmar que existe un APK** sin compilarlo.
4. **Audio** (BLOQUEADO: los 22 WAV no vienen en este ZIP, solo `intro_narration_es_mx.wav`): cuando el usuario los adjunte, integrarlos corrigiendo DC, clipping y costuras de bucle (conservar originales); regenerar `audio-index.json` (`tools/build_audio_index.py`) y `data/offline_assets.json`; prueba automática de chispa+sonido por tipo de golpe. Hoy el motor cae al sintetizador procedural, así que el juego no se queda mudo.
5. **Motor, mejoras posibles** (decidir JUGANDO): clip de bloqueo de pie — hoy `STATE_CLIP.BLOCK/BLOCKSTUN = "crouch_guard"` (engine/pg_sim.js:28) para los 32 personajes; NINGUNO trae clip de guardia de pie declarado, y `f.clip` vive en el MatchState serializable, así que cambiarlo altera la huella determinista y exige arte por personaje + verlo en el teléfono. Botón SP de Diego: hoy dispara la llave de comando (primer especial de su lista).
6. **Pulido del menú:** ~~8 escenarios sin deslizar a 1280 px~~ **HECHO 2026-10-27** (envuelven con altura ≥600; teléfono paisaje bajo intacto). Quedan: fichas con mucho hueco en teléfono vertical; la última fila de etiquetas de rasgo puede recortarse en fichas bajas.
7. **Hallazgos sin resolver:** M8 (`vida` del char.json solo se muestra; el motor usa `fighters.hp`=300), `measure_strikes`/`build_normals` ignoran `anchorsFile`, `pack_fx_library` sin su fuente, `don_pepe → cartel` en Arcade 3v3 es reemplazo provisional (`TODO: VERIFICAR`). (`audit_all_atlases` ya NO da falsos positivos de Nina: corregido 2026-10-27.)
8. **Entrega final:** ZIP único con manifiesto SHA-256, README, `docs/PROJECT_STATUS.md`, `docs/CHANGELOG.md` e informe de QA (las entregas intermedias ya salen así).

## 6. Mapa rápido de archivos tocados en esta etapa

| Área | Archivos |
|---|---|
| Consolidación 2026-10-27 | `tools/audit_all_atlases.py` (lee `coordsFile`; nuevo chequeo `coords_out_of_bounds`), `styles/game.css` (strip de escenarios envuelve con altura ≥600) |
| Motor | `engine/pg_sim.js` (súper-cancel, golpe de comando), `engine/pg_render.js` (orden de dibujo), `engine/pg_frontend.js` + `engine/pg_game.js` (combates del Arcade) |
| Datos | `data/config.json` (`hit.superCancel`), `data/roster.json` (el_aedillo), `data/hidden_particle_fx.json`, `data/offline_assets.json`, `sw.js` = `public/sw.js` (caché v6) |
| Personajes | `assets/combat/mateo/` (atlas nuevo; derivados viejos retirados), `assets/combat/valentina_niebla/` (energia, victoria), `assets/combat/diego_cancha/` (golpes), `assets/combat/el_aedillo/` (nuevo), jefes y `sofi` (tiempos) |
| Herramientas | `tools/combo_check.js`, `tools/combo_list.js`, `tools/build_seated_char.py`, `tools/cut_painted_checker.py`, `tools/build_diego_hojas.py`, `tools/build_valentina_nadia.py`, `tools/specs/{mateo_seated,el_aedillo_seated,diego_hojas_spec,valentina_nadia_spec,combo_expect}.json`, `tools/run_regression.sh` (paso 20; busca Chromium solo) |
| Pruebas | `tools/test_sim.js` (197), `qa/test_arcade_campaigns.py` (provisionales leídos del roster) |
| Fuentes originales (con SHA256SUMS) | `sources/mateo/`, `sources/valentina_niebla/nadia/`, `sources/diego_cancha/hojas/`, `sources/el_aedillo/`, `sources/candidatos/bola_y_cadena/` |
| Informes | `qa/COMBOS_VERIFICADOS.md`, `qa/mateo/`, `qa/valentina_niebla/`, `qa/diego_cancha/`, `qa/el_aedillo/`, `qa/runs/2026-10-26_entrega/` |

## 7. Historial git

Este ZIP no incluye la carpeta `.git`. Base de esta etapa: `PuenteGrande_LegendOfPresos_2026-10-25.zip`
(SHA-256 `e7ad2371…4bef47`, 847 archivos en su manifiesto). En Drive (carpeta Kofitel) están los `CONTINUAR_AQUI_<fecha>.md`;
los ZIP del proyecto no se pueden subir desde el chat (el conector de Drive recibe el contenido dentro de la llamada y un ZIP de más de 100 MB no cabe): los guarda el usuario.
