/* pg-render-pixi.js — Capa de RENDER PixiJS para Legend of Presos (PG-Core).
   Reemplaza SOLO el dibujo (Canvas 2D → PixiJS). NO toca el motor ni los datos:
   lee exactamente el mismo contrato que el render Canvas de game.js:
     - PJ[id] = { imgs:[Image|url], frameMap, pivote{local_x,local_y}, celda, cols, nImg }
     - celdaDe(a, idx) -> { img|page, sx,sy,w,h, pivot:[x,y], scale, alphaBounds }
     - dibujaCuerpo: pies en (px,py), scale renderScale, flip facing, maxMode/invuln/alterno
   Así el núcleo (Pelea, PP, clipDe/frameDe, colisiones) sigue intacto. */
(function (global) {
  "use strict";

  // Mismo cálculo que celdaDe() de game.js (frameMap o rejilla).
  function celdaDe(a, idx) {
    if (a.frameMap) {
      var e = a.frameMap[idx], r = e.rect;
      return { page:e.page, sx:r[0], sy:r[1], w:r[2], h:r[3], pivot:e.pivot, scale:e.renderScale, alphaBounds:e.alphaBounds };
    }
    var k = 0, i = idx;
    while (k < a.imgs.length - 1 && i >= a.nImg[k]) { i -= a.nImg[k]; k++; }
    var pv = a.pivote || { local_x:(a.cw/2), local_y:a.ch };
    return { page:k, sx:(i % a.cols) * a.cw, sy:Math.floor(i / a.cols) * a.ch, w:a.cw, h:a.ch, pivot:[pv.local_x, pv.local_y], scale:1 };
  }

  function PGRenderPixi(opts) {
    this.opts = opts || {};
    this.app = null;
    this.baseTex = {};     // id -> [PIXI.Texture page]
    this.frameTex = {};    // id -> { idx -> PIXI.Texture }
    this.world = null;
    this.layers = {};
    this.sprites = {};     // key -> PIXI.Sprite (reutilizados)
    this.hue = {};         // cache de filtros hue por grado
  }

  PGRenderPixi.prototype.init = async function (mountEl, cfg) {
    cfg = cfg || {};
    this.SUELO = cfg.SUELO != null ? cfg.SUELO : 300;
    this.worldW = cfg.worldW || 960; this.worldH = cfg.worldH || 540;
    var app = new PIXI.Application();
    await app.init({ background: cfg.background || "#100e18", antialias: false,
      width: cfg.width || this.worldW, height: cfg.height || this.worldH, roundPixels: true });
    (mountEl || document.body).appendChild(app.canvas);
    this.app = app;
    this.world = new PIXI.Container();
    this.layers.bg = new PIXI.Container();
    this.layers.shadow = new PIXI.Container();
    this.layers.chars = new PIXI.Container();
    this.layers.fx = new PIXI.Container();
    this.layers.debug = new PIXI.Graphics();
    this.world.addChild(this.layers.bg, this.layers.shadow, this.layers.chars, this.layers.fx, this.layers.debug);
    app.stage.addChild(this.world);
    this.fit();
    return this;
  };

  PGRenderPixi.prototype.fit = function () {
    var vw = this.app.renderer.width, vh = this.app.renderer.height;
    var s = Math.min(vw / this.worldW, vh / this.worldH);
    this.world.scale.set(s);
    this.world.x = (vw - this.worldW * s) / 2;
    this.world.y = (vh - this.worldH * s) / 2;
    this._scale = s;
  };

  // Carga las páginas de atlas de un personaje como texturas PIXI.
  PGRenderPixi.prototype.loadCharacter = async function (id, pageUrls) {
    if (this.baseTex[id]) return;
    var texs = [];
    for (var i = 0; i < pageUrls.length; i++) texs.push(await PIXI.Assets.load(pageUrls[i]));
    this.baseTex[id] = texs; this.frameTex[id] = {};
  };

  PGRenderPixi.prototype._tex = function (a, idx) {
    var id = a.id, cache = this.frameTex[id] || (this.frameTex[id] = {});
    if (cache[idx]) return cache[idx];
    var c = celdaDe(a, idx), base = this.baseTex[id][c.page];
    var t = new PIXI.Texture({ source: base.source, frame: new PIXI.Rectangle(c.sx, c.sy, c.w, c.h) });
    t._pg = c; cache[idx] = t; return t;
  };

  PGRenderPixi.prototype._sprite = function (key) {
    var s = this.sprites[key];
    if (!s) { s = new PIXI.Sprite(); this.sprites[key] = s; this.layers.chars.addChild(s); }
    s.visible = true; return s;
  };

  PGRenderPixi.prototype._hueFilter = function (deg) {
    if (!this.hue[deg]) { var f = new PIXI.ColorMatrixFilter(); f.hue(deg, false); this.hue[deg] = f; }
    return this.hue[deg];
  };

  /* Equivalente a dibujaCuerpo(): pies en (x, y=SUELO+alt), facing 1/-1.
     opts: { maxMode, invuln, alterno, maxPulseFrame } */
  PGRenderPixi.prototype.drawFighter = function (key, a, idx, x, y, facing, opts) {
    opts = opts || {};
    var tex = this._tex(a, idx), c = tex._pg, spr = this._sprite(key);
    spr.texture = tex;
    spr.anchor.set(c.pivot[0] / c.w, c.pivot[1] / c.h);
    spr.position.set(x, y);
    spr.scale.set(c.scale * (facing < 0 ? -1 : 1), c.scale);
    spr.alpha = (opts.invuln && !opts.noBlink) ? 0.72 : 1;
    var filters = [];
    if (opts.alterno) filters.push(this._hueFilter(145));
    spr.filters = filters.length ? filters : null;
    spr.tint = opts.maxMode ? 0xffe8b0 : 0xffffff;
    // sombra
    this.drawShadow(key + "_sh", x, (opts.alt || 0));
    return spr;
  };

  PGRenderPixi.prototype.drawShadow = function (key, x, alt) {
    var g = this.sprites[key];
    if (!g) { g = new PIXI.Graphics(); this.sprites[key] = g; this.layers.shadow.addChild(g); }
    var e = Math.max(0.35, 1 + alt / 260);
    g.clear(); g.ellipse(x, this.SUELO + 2, 26 * e, 5 * e).fill({ color: 0x000000, alpha: 0.45 });
    g.visible = true;
  };

  PGRenderPixi.prototype.setStageImage = function (tex) {
    this.layers.bg.removeChildren();
    if (!tex) return;
    var s = new PIXI.Sprite(tex); s.width = this.worldW; s.height = this.worldH; this.layers.bg.addChild(s);
  };
  PGRenderPixi.prototype.setStageColor = function (top, bottom) {
    this.layers.bg.removeChildren();
    var g = new PIXI.Graphics();
    g.rect(0,0,this.worldW,this.SUELO).fill(top||0x241a33);
    g.rect(0,this.SUELO,this.worldW,this.worldH-this.SUELO).fill(bottom||0x12101a);
    g.rect(0,this.SUELO,this.worldW,3).fill(0x5a4780);
    this.layers.bg.addChild(g);
  };

  // Proyectil dibujado con arte de atlas (celdaDe) — equivale a dibujaArrojadizo(atlas).
  PGRenderPixi.prototype.drawProjectileAtlas = function (key, a, idx, x, y, facing, scale) {
    var tex=this._tex(a,idx), c=tex._pg, spr=this.sprites[key];
    if(!spr){ spr=new PIXI.Sprite(); this.sprites[key]=spr; this.layers.fx.addChild(spr); }
    spr.texture=tex; spr.anchor.set(0.5,0.5); spr.position.set(x,y);
    spr.scale.set((scale||1)*(facing<0?-1:1),(scale||1)); spr.visible=true;
  };

  // Oculta sprites no usados este frame (llamar hide() + marcar vistos, o usar beginScene).
  PGRenderPixi.prototype.beginScene = function () { this._seen = {}; };
  PGRenderPixi.prototype.markSeen = function (key) { if (this._seen) this._seen[key] = 1; };
  PGRenderPixi.prototype.endScene = function () {
    if (!this._seen) return;
    for (var k in this.sprites) if (!this._seen[k]) this.sprites[k].visible = false;
  };

  PGRenderPixi.prototype.drawDebugBoxes = function (boxes) {
    var g = this.layers.debug; g.clear();
    (boxes || []).forEach(function (b) {
      var col = b.t === "hit" ? 0xff4b3e : b.t === "hurt" ? 0x3d9bff : b.t === "throw" ? 0xd584ff : 0x3ddc84;
      g.rect(b.x, b.y, b.w, b.h).stroke({ color: col, width: 1.2, alpha: 0.9 });
    });
  };

  PGRenderPixi.celdaDe = celdaDe;
  global.PGRenderPixi = PGRenderPixi;
})(window);
