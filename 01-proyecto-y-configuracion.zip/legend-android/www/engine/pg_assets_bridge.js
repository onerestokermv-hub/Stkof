/* Puente Grande - puente de recursos PixiJS. No modifica el motor. */
(function(global){
  const PGAssets = {
    manifest: null,
    async loadManifest(url='data/runtime_manifest.json') {
      const r = await fetch(url, {cache:'no-store'});
      if (!r.ok) throw new Error(`PGAssets manifest HTTP ${r.status}`);
      this.manifest = await r.json();
      return this.manifest;
    },
    resolveAlias(id){
      if(!this.manifest) return id;
      return this.manifest.character_aliases?.[id] || id;
    },
    listCuratedBase(){
      if(!this.manifest) throw new Error('Carga primero runtime_manifest.json');
      return (this.manifest.characters_base_curated || this.manifest.characters_base || []).slice();
    },
    getCuratedCharacterIds(){
      if(!this.manifest) throw new Error('Carga primero runtime_manifest.json');
      return (this.manifest.characters_base_curated || this.manifest.characters_base || []).map(x=>x.id);
    },
    listStages(){
      if(!this.manifest) throw new Error('Carga primero runtime_manifest.json');
      return (this.manifest.backgrounds || []).slice();
    },
    listSpecials(){
      if(!this.manifest) throw new Error('Carga primero runtime_manifest.json');
      return (this.manifest.characters_specials || []).slice();
    },
    async loadBaseCharacter(id, curated=true) {
      if (!this.manifest) await this.loadManifest();
      id = this.resolveAlias(id);
      const source = curated ? (this.manifest.characters_base_curated || this.manifest.characters_base) : this.manifest.characters_base;
      const e = source.find(x=>x.id===id) || this.manifest.characters_base.find(x=>x.id===id);
      if (!e) throw new Error(`Atlas base no encontrado: ${id}`);
      return PIXI.Assets.load(e.atlas);
    },
    async loadSpecials(id) {
      if (!this.manifest) await this.loadManifest();
      id = this.resolveAlias(id);
      const e = this.manifest.characters_specials.find(x=>x.id===id);
      if (!e) return null;
      return PIXI.Assets.load(e.atlas);
    },
    async loadCharacter(id, specialsId=id) {
      const [base, specials] = await Promise.all([this.loadBaseCharacter(id, true), this.loadSpecials(specialsId)]);
      return {base, specials};
    },
    getStage(id) {
      if (!this.manifest) throw new Error('Carga primero runtime_manifest.json');
      return this.manifest.backgrounds.find(x=>x.game_id===id) || null;
    }
  };
  global.PGAssets = PGAssets;
})(window);