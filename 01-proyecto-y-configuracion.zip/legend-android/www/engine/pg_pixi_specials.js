(function(root){"use strict";
const BASE="assets/specials";
const DEFS={
cochi_bombis:["cuerpo_pesado","patada_voladora","terremoto"],
don_gorron:["colmillo_verde","patada_voladora","rata_fantasma"],
regente:["corte_sombrio","patada_voladora","poder_rojo"],
mateo:["rush_brutal","patada_voladora","impacto_rojo"],
el_oscuro:["rush_sombra","patada_voladora","vortice"]};
const ALIAS={oscuro:"el_oscuro",oscuro_specials:"el_oscuro",regente_final:"regente",regente_jefe:"regente",cochi:"cochi_bombis"};
const cache=new Map();
function resolveId(id){return ALIAS[id]||id;}
function listCharacters(){return Object.keys(DEFS);}
function listMoves(id){id=resolveId(id); return (DEFS[id]||[]).slice();}
async function loadCharacter(id,base=BASE){
 id=resolveId(id);
 if(!root.PIXI)throw new Error("PIXI no está cargado");
 if(!DEFS[id])throw new Error("Personaje no registrado: "+id);
 if(cache.has(id))return cache.get(id);
 const sheet=await root.PIXI.Assets.load(`${base}/${id}/${id}_atlas.json`);
 cache.set(id,sheet);return sheet;
}
async function loadAll(base=BASE){
 const list=await Promise.all(Object.keys(DEFS).map(async id=>[id,await loadCharacter(id,base)]));
 return Object.fromEntries(list);
}
async function createClip(id,move,opt={}){
 id=resolveId(id);
 const sheet=await loadCharacter(id,opt.base||BASE);
 const textures=sheet.animations?.[move];
 if(!textures?.length)throw new Error(`Clip inexistente: ${id}/${move}`);
 const s=new root.PIXI.AnimatedSprite(textures);
 s.anchor.set(.5,116/120);
 s.loop=opt.loop??false;
 s.animationSpeed=(opt.fps??12)/60;
 s.autoUpdate=opt.autoUpdate??true;
 if(opt.play!==false)s.play();
 return s;
}
root.PGPixiSpecials=Object.freeze({BASE,DEFS,ALIAS,resolveId,listCharacters,listMoves,loadCharacter,loadAll,createClip,
 hasMove:(id,m)=>!!DEFS[resolveId(id)]?.includes(m)});
})(globalThis);