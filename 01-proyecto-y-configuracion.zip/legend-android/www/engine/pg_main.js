/* pg_main — arranque de la base modular PIXI. */
(function () {
  "use strict";
  const $ = s => document.querySelector(s);
  const state = { roster: null, arena: null, app: null, sel: null, cache: {} };

  async function boot(){
    const app = new PIXI.Application();
    await app.init({ background: '#140f1a', resizeTo: window, antialias: false, roundPixels: true });
    $('#game').appendChild(app.canvas);
    state.app = app;
    state.arena = new PGArena(app);

    state.roster = await (await fetch('data/roster.json', {cache:'no-store'})).json();
    buildSelector();
    buildControls();

    // fondo (patio) — best-effort
    state.arena.setBackgroundSVG('assets/backgrounds/patio_b.svg');

    // primer personaje con fuente canónica V248
    const first = state.roster.roster.find(r => r.tipo_fuente === 'v248') || state.roster.roster[0];
    await selectCharacter(first.id);

    window.__PG = state;
    window.__READY = true;
  }

  function buildSelector(){
    const box = $('#selector'); box.innerHTML = '';
    for (const r of state.roster.roster){
      const b = document.createElement('button');
      b.dataset.id = r.id;
      b.innerHTML = `${r.id}<span class="f">${r.frames||'?'}f</span>`;
      if (r.tipo_fuente !== 'v248') b.classList.add('borrador');
      b.onclick = () => selectCharacter(r.id);
      box.appendChild(b);
    }
  }

  function buildControls(){
    document.querySelectorAll('#controles [data-anim]').forEach(btn=>{
      btn.onclick = () => {
        const f = state.arena.fighter; if (!f) return;
        const a = btn.dataset.anim;
        if (a === '__especial'){ f.playSpecialFirst(); return; }
        f.play(a, { loop:true, fps: a==='all'?14:8 });
      };
    });
    $('#btn-flip').onclick = () => state.arena.fighter && state.arena.fighter.flip();
  }

  async function selectCharacter(id){
    const r = state.roster.roster.find(x => x.id === id);
    if (!r || !r.cuerpo) return;
    document.querySelectorAll('#selector button').forEach(b =>
      b.classList.toggle('sel', b.dataset.id === id));
    $('#ficha-nombre').textContent = id;
    $('#ficha-meta').textContent = `${r.tipo_fuente} · ${r.frames||'?'} frames` + (r.especiales ? ' · especiales ✓' : '');

    if (!state.cache[id]){
      const body = await PGLoader.loadBody(r.cuerpo, r.tipo_fuente);
      const specials = await PGLoader.loadSpecials(r.especiales);
      state.cache[id] = new PGFighter(body, specials);
    }
    state.arena.setFighter(state.cache[id], { scale: r.tipo_fuente==='v248' ? 2.2 : 2.6 });
    state.sel = id;
  }

  window.addEventListener('error', e => { window.__PG_ERR = String(e.message||e.error); });
  boot().catch(e => { window.__PG_ERR = String(e); window.__READY = true; });
})();
