/* PGArena — escena PIXI: fondo, suelo (y=790 lógico sobre lienzo 21:9), un luchador.
   Base para el combate; el motor de pelea se conecta aquí en la siguiente fase. */
(function (global) {
  "use strict";
  const LOGICAL_W = 2520, LOGICAL_H = 1080, FLOOR_Y = 790; // del backgrounds_manifest

  class PGArena {
    constructor(app){
      this.app = app;
      this.root = new PIXI.Container();
      this.world = new PIXI.Container();   // se escala para encajar 21:9
      this.bgLayer = new PIXI.Container();
      this.fxLayer = new PIXI.Container();
      this.charLayer = new PIXI.Container();
      this.world.addChild(this.bgLayer, this.charLayer, this.fxLayer);
      this.root.addChild(this.world);
      app.stage.addChild(this.root);
      this.fighter = null;
      this._drawBackdrop();
      this._layout();
      window.addEventListener('resize', () => this._layout());
    }

    _drawBackdrop(){
      const g = new PIXI.Graphics();
      // cielo
      g.rect(0,0,LOGICAL_W,LOGICAL_H).fill(0x241a33);
      g.rect(0,0,LOGICAL_W,FLOOR_Y).fill({color:0x2e2140});
      // muro perimetral sugerido
      for(let x=0;x<LOGICAL_W;x+=210){ g.rect(x+6,180,198,FLOOR_Y-220).fill({color:0x3a2b52,alpha:0.5}); }
      // suelo
      g.rect(0,FLOOR_Y,LOGICAL_W,LOGICAL_H-FLOOR_Y).fill(0x15101e);
      g.rect(0,FLOOR_Y,LOGICAL_W,6).fill(0x5a4780);
      this.bgLayer.addChild(g);
      this._floorG = g;
    }

    async setBackgroundSVG(url){
      try{
        const tex = await PIXI.Assets.load(url);
        const spr = new PIXI.Sprite(tex);
        spr.width = LOGICAL_W; spr.height = LOGICAL_H;
        this.bgLayer.removeChildren(); this.bgLayer.addChild(spr);
        // re-dibujar línea de suelo encima
        const line = new PIXI.Graphics().rect(0,FLOOR_Y,LOGICAL_W,5).fill({color:0x000000,alpha:0.25});
        this.bgLayer.addChild(line);
        return true;
      }catch(e){ PGLoader.DBG.lastError='bg:'+e; return false; }
    }

    setFighter(fighter, { scale = 2.2 } = {}){
      // la caché es dueña de los luchadores: solo se quitan de la capa, NO se destruyen
      if (this.fighter && this.fighter !== fighter){ this.charLayer.removeChild(this.fighter.view); }
      if (this.fighter === fighter && fighter.view.parent === this.charLayer){
        // re-selección del mismo: nada que recrear
      }
      this.fighter = fighter;
      fighter.setScale(scale);
      fighter.view.x = LOGICAL_W * 0.5;
      fighter.view.y = FLOOR_Y;            // los pies (anchor ~0.94) quedan sobre el suelo
      // sombra
      if (!this._shadow){
        this._shadow = new PIXI.Graphics();
        this.charLayer.addChild(this._shadow);
      }
      this._shadow.clear().ellipse(LOGICAL_W*0.5, FLOOR_Y+6, 110, 26).fill({color:0x000000, alpha:0.35});
      this.charLayer.addChild(fighter.view);
    }

    _layout(){
      const vw = this.app.renderer.width, vh = this.app.renderer.height;
      const s = Math.min(vw/LOGICAL_W, vh/LOGICAL_H);
      this.world.scale.set(s);
      this.world.x = (vw - LOGICAL_W*s)/2;
      this.world.y = (vh - LOGICAL_H*s)/2;
    }
  }
  PGArena.LOGICAL_W = LOGICAL_W; PGArena.LOGICAL_H = LOGICAL_H; PGArena.FLOOR_Y = FLOOR_Y;
  global.PGArena = PGArena;
})(window);
