/* pg_boot_combat — arranque del combate PIXI con PASO FIJO 1/60 (spec §4.1).
   Acumulador + clamp anti-espiral. Sim y render separados. */
(function () {
  "use strict";
  const STEP_MS = 1000/60, MAX_STEPS = 5;
  const state = { app:null, match:null, render:null, p1:null, defs:null, ai:true };

  // Resuelve los dos luchadores desde data/roster.json (?p1=&p2= en la URL los sobreescriben).
  async function resolveRoster(){
    const roster = await (await fetch("data/roster.json",{cache:"no-store"})).json();
    const byId = {}; roster.characters.forEach(c=>byId[c.id]=c);
    const q = new URLSearchParams(location.search);
    const pickable = roster.characters.filter(c=>c.status==="playable").map(c=>c.id);
    const pick = (param, def) => {
      const v = q.get(param);
      if (v && byId[v] && byId[v].status==="playable") return v;
      return (def && byId[def] && byId[def].status==="playable") ? def : pickable[0];
    };
    const id1 = pick("p1", roster.default && roster.default.p1);
    const id2 = pick("p2", roster.default && roster.default.p2);
    return { c1: byId[id1], c2: byId[id2], roster };
  }

  // audio sintético mínimo (consume match.events) — sin dependencias
  // el navegador solo deja crear audio tras un gesto del usuario: antes se creaba con el primer evento del combate y
  // la consola mostraba "AudioContext was not allowed to start". Ahora se crea en la primera tecla/toque.
  let actx=null, gestured=false;
  const onGesture=()=>{ gestured=true; window.removeEventListener("keydown",onGesture,true); window.removeEventListener("pointerdown",onGesture,true); };
  window.addEventListener("keydown",onGesture,true); window.addEventListener("pointerdown",onGesture,true);
  function audio(){ if(!actx && gestured){ const C=window.AudioContext||window.webkitAudioContext; if(C) actx=new C(); } return actx; }
  function beep(type){
    const c=audio(); if(!c) return;
    const dur = type==="super"?0.5:type==="heavy"?0.22:type==="ko"?0.5:0.08;
    const b=c.createBuffer(1,Math.max(1,c.sampleRate*dur),c.sampleRate), d=b.getChannelData(0);
    for(let i=0;i<d.length;i++) d[i]=(Math.random()*2-1)*Math.exp(-i/(c.sampleRate*(dur*0.3)));
    const s=c.createBufferSource(); s.buffer=b;
    const f=c.createBiquadFilter(); f.type=(type==="super"||type==="heavy"||type==="ko")?"lowpass":"highpass";
    f.frequency.value=(type==="light"||type==="block")?900:300;
    const g=c.createGain(); g.gain.setValueAtTime(type==="super"?0.6:0.35,c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.01,c.currentTime+dur);
    s.connect(f); f.connect(g); g.connect(c.destination); s.start();
  }

  async function boot(){
    const app=new PIXI.Application();
    await app.init({ background:"#0f0b16", resizeTo:window, antialias:false, roundPixels:true });
    document.getElementById("game").appendChild(app.canvas);
    state.app=app;

    state.config = await (await fetch("data/config.json",{cache:"no-store"})).json();
    const { c1, c2 } = await resolveRoster();
    const def1 = await (await fetch(c1.dir+c1.char,{cache:"no-store"})).json();
    const def2 = await (await fetch(c2.dir+c2.char,{cache:"no-store"})).json();
    const p0 = await PGLoader.loadGridCharacter(def1, c1.dir);
    const p1 = await PGLoader.loadGridCharacter(def2, c2.dir);
    state.defs=[p0.def, p1.def];

    state.match = PGSim.createMatch(0xC0FFEE, state.config);
    const fxLib = await PGLoader.loadFxLibrary('data/fx_library.json', [p0.def, p1.def]);
    // escenario: el mismo data/stages.json que game.html (?stage=<id>; por defecto el primero, Puente Grande)
    const stages = (await (await fetch("data/stages.json",{cache:"no-store"})).json()).stages || [];
    const want = new URLSearchParams(location.search).get("stage");
    const stageDef = stages.find(function(s){ return s.id === want; }) || stages[0] || null;
    const stageTex = stageDef ? await PGLoader.loadStageArt(stageDef) : null;
    state.render = new PGRender(app, [p0, p1], { fx: fxLib, stageDef: stageDef, stageTex: stageTex });

    state.p1 = new PGInput.Controller();
    state.p1.attachKeyboard(window);
    if (window.PGTouch) PGTouch.mount(document.getElementById("pad"), state.p1);
    else state.p1.attachTouch(document.getElementById("pad"));

    wireUI();
    window.__PGC = state;

    let acc=0, last=performance.now();
    function frame(now){
      acc += now-last; last=now;
      let steps=0;
      while(acc>=STEP_MS && steps<MAX_STEPS){ simStep(); acc-=STEP_MS; steps++; }
      if(steps===MAX_STEPS) acc=0;
      state.render.render(state.match);
      requestAnimationFrame(frame);
    }
    state.__ready=false;
    requestAnimationFrame(t=>{ last=performance.now(); requestAnimationFrame(frame); state.__ready=true; window.__READY=true; });
  }

  function simStep(){
    const m=state.match; if(m.over) return;
    const in0=state.p1.snapshot();
    const in1=state.ai ? PGAI.decide(m, m.fighters[1], m.fighters[0], 1, state.defs[1])
                       : {x:0,down:false,block:false,upPress:false,punchPress:false,kickPress:false,specialPress:false,superPress:false};
    PGSim.step(m, state.defs, [in0, in1]);
    if(m.events.length){ for(const e of m.events) beep(e.t); m.events.length=0; }
  }

  function wireUI(){
    document.addEventListener("keydown", e=>{
      const k=e.key.toLowerCase();
      if(k==="f"){ state.render.debug=!state.render.debug; }
      if(k==="r"){ restart(); }
      if(k==="p"){ state.ai=!state.ai; }
    });
    const dbgBtn=document.getElementById("btn-debug"); if(dbgBtn) dbgBtn.onclick=()=>state.render.debug=!state.render.debug;
    const rBtn=document.getElementById("btn-restart"); if(rBtn) rBtn.onclick=restart;
  }
  function restart(){ state.match = PGSim.createMatch((Math.random()*1e9)>>>0, state.config); }

  window.addEventListener("error", e=>{ window.__PGC_ERR=String(e.message||e.error); });
  boot().catch(e=>{ window.__PGC_ERR=String(e&&e.stack||e); window.__READY=true; });
})();
