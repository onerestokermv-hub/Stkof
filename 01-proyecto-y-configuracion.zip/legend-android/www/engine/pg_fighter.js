/* PGFighter — un luchador en pantalla: AnimatedSprite con reproducción de clips.
   Mantiene cuerpo y especiales como fuentes separadas (no se mezclan). */
(function (global) {
  "use strict";

  class PGFighter {
    constructor(body, specials){
      this.body = body;
      this.specials = specials;        // puede ser null
      this.current = null;
      this.anim = new PIXI.AnimatedSprite(this._clip('idle_tentativo') || this._firstClip());
      this.anim.anchor.set(body.anchor.x, body.anchor.y);
      this.anim.animationSpeed = 10/60;
      this.anim.loop = true;
      this.anim.play();
      this.view = this.anim;
      this.current = 'idle_tentativo';
    }
    _clip(name){
      const a = this.body.animations || {};
      return a[name] || null;
    }
    _firstClip(){
      const a = this.body.animations || {};
      return a.idle_walk || a.all || Object.values(a)[0] || [PIXI.Texture.WHITE];
    }
    listBodyClips(){ return Object.keys(this.body.animations || {}); }
    listSpecialClips(){ return this.specials ? Object.keys(this.specials.animations || {}) : []; }

    play(name, { loop = true, fps = 10, from = 'body' } = {}){
      const src = (from === 'special' && this.specials) ? this.specials.animations : this.body.animations;
      const frames = src[name];
      if (!frames || !frames.length) return false;
      this.anim.textures = frames;
      // ancla: especiales traen su propio anchor (120x120, ~0.5/0.97)
      if (from === 'special') this.anim.anchor.set(0.5, 0.9667);
      else this.anim.anchor.set(this.body.anchor.x, this.body.anchor.y);
      this.anim.loop = loop;
      this.anim.animationSpeed = fps/60;
      this.anim.gotoAndPlay(0);
      this.current = name;
      return true;
    }
    playSpecialFirst(){
      const names = this.listSpecialClips();
      if (!names.length) return false;
      return this.play(names[0], { loop:true, fps:12, from:'special' });
    }
    setScale(s){ const sx = Math.sign(this.anim.scale.x)||1; this.anim.scale.set(s); this.anim.scale.x = s*sx; }
    flip(){ this.anim.scale.x *= -1; }
    destroy(){ this.anim.destroy(); }
  }
  global.PGFighter = PGFighter;
})(window);
