# Migración del render a PixiJS — Legend of Presos (PG-Core)

**Objetivo:** cambiar SOLO la capa de dibujo (Canvas 2D → PixiJS) del juego real
(`game_js`), conservando el motor (`js/core/pg-*`), los datos (`LOP_DATA`,
`frameMap`, `PGPersonajes`) y los 18+ personajes. El render **nunca** modifica el
estado (spec §4.1), así que esto es un reemplazo de backend, no un rewrite del juego.

## Lo que YA está hecho y verificado
- `engine/pg-render-pixi.js` — backend PixiJS fiel al contrato de `game.js`:
  - `celdaDe(a, idx)` idéntico (frameMap o rejilla).
  - `drawFighter(key,a,idx,x,y,facing,opts)` = equivalente exacto de `dibujaCuerpo`:
    ancla por `pivot/w, pivot/h`, escala `renderScale`, flip por `facing`,
    `invuln`→alpha .72, `alterno`→hue-rotate(145), `maxMode`→tint + sombra.
  - `drawShadow`, `setStageImage`/`setStageColor`, `drawProjectileAtlas`,
    `drawDebugBoxes`, y `beginScene/markSeen/endScene` (reutiliza sprites, oculta los no usados).
- Verificado renderizando **datos reales** (Táctico Púrpura, 42 estados, 2 luchadores
  enfrentados) en Chromium, **0 errores**. Pivotes al suelo y flip correctos.

## Mapa de reemplazo (función Canvas → llamada PIXI)
En `game.js`, el dibujo vive en estas funciones. Se cambia el CUERPO de cada una por
la llamada equivalente; **las firmas y los llamadores no cambian**.

| game.js (Canvas)                      | Reemplazo PIXI (`R = PGRenderPixi`)                    |
|---|---|
| `dibujaCuerpo(s,i,x,alt)`             | `R.drawFighter('p'+i, PJ[s.def.id], clipDe(s).idx, sn(x), sn(SUELO+alt), s.act.facing, {maxMode:s.pel.maxMode, invuln:s.pel.invuln, alterno:PJ[s.def.id].alterno, alt})` |
| `sombra(x,alt)`                       | lo hace `drawFighter` (llama `drawShadow`)             |
| `escenario()/pintaEscenarioEn()`      | `R.setStageImage(texDelEscenario)` o `R.setStageColor()` |
| `dibujaProy()` (arte `atlas`)         | `R.drawProjectileAtlas('proy'+n, PJ[id], idx, x, y, facing, scale)` |
| `dibujaArrojadizo()` (atlas)          | igual que arriba (es arte de atlas)                   |
| `dibujaFx()` (e.atlasId / newFxId)    | sprite de atlas en capa `fx` (mismo patrón que proyectil) |
| `dibujaCajas()` (modo debug)          | `R.drawDebugBoxes([{t:'push'|'hurt'|'hit'|'throw',x,y,w,h}])` |
| `pinta()` (orquesta la escena)        | `R.beginScene(); …dibuja…; R.endScene();`             |

### El estado que lee el render (no cambia)
- `Pelea.p.lados[i]` → luchador `s`; `s.act.x`, `s.alt`, `s.act.facing`, `s.pel.*`.
- `clipDe(s)/frameDe(s)` → índice de cuadro (del núcleo). **Se siguen usando igual.**
- Interpolación: se conserva (`Pelea.antes`, `entre()`); solo cambia a quién se le
  pasan los `x,y` ya interpolados (ahora a `R.drawFighter` en vez de `ctx.drawImage`).
- `SUELO`, `ESC`, `sn()`: el mundo PIXI usa su propio contenedor escalado
  (`R.fit()`), así que `sn()`/`ESC` dejan de aplicarse al dibujo (Pixi escala el
  contenedor); las coordenadas lógicas (`x`, `SUELO+alt`) se pasan tal cual.

## Pasos de integración (incrementales, sin romper)
1. En `index.html`: cargar `pixi.min.js` y `engine/pg-render-pixi.js` antes de `game.js`.
   Crear el render: `const R = new PGRenderPixi(); await R.init(contenedor,{worldW,worldH,SUELO});`
   y, por personaje en pantalla, `await R.loadCharacter(id, IMG[id])`.
2. Reemplazar **solo** `dibujaCuerpo` y `sombra` por `R.drawFighter` (deja el resto en
   Canvas de momento: Pixi y Canvas pueden convivir una capa sobre otra mientras migras).
3. Mover escenario y proyectiles/FX de atlas a Pixi.
4. HUD y FX vectoriales (barras, anillos de impacto, orbe con gradiente, cadena/bastón):
   reimplementar con `PIXI.Graphics` (equivalentes directos) **o** dejarlos en una capa
   Canvas 2D encima mientras tanto. No bloquean el combate.
5. Verificar en navegador: **consola limpia** (DoD §8) y que un combo cuente igual al frame
   (el motor no cambió, así que debe ser idéntico; si difiere, el bug está en el render).

## Pendiente para COMPLETAR y verificar en el juego entero
Faltan assets que no vinieron en los zips y hacen falta para bootear el juego real y
verificar la consola limpia de extremo a extremo:
- `assets/auditados/*.png` (atlas base del roster — los referencia `assets.js`).
- `assets/runtime_211/stages/*.png` (escenarios) y `assets/runtime_211/bigotes/vaquero.png`.
- El `index.html` del juego (orden de carga de los ~34 módulos) — o autorización para
  reconstruirlo desde los módulos.

Con eso hago el swap dentro del juego y lo valido corriendo (consola 0 errores, combos al frame).
