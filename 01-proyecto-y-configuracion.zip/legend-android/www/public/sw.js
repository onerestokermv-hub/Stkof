/* sw.js — Service Worker para Legend of Presos (PWA 100% offline).
   Caché estática de arranque + almacenamiento dinámico automático de atlas, fondos y datos. */

const CACHE_NAME = 'legend-of-presos-v7';   // v7 (2026-10-27): nombres confirmados y Regente como abogado; combate intacto

const STATIC_ASSETS = [
  './',
  './game.html',
  './combate.html',
  './index.html',
  './manifest.webmanifest',
  './styles/game.css',
  './styles/combate.css',
  './styles/main.css',
  './styles/fonts/inter-400.woff',
  './styles/fonts/inter-600.woff',
  './styles/fonts/inter-800.woff',
  './styles/fonts/texgyreheroscn-bold.otf',
  './data/config.json',
  './data/roster.json',
  './data/canonical_names.json',
  './data/stages.json',
  './data/campaigns.json',
  './data/normals.json',
  './data/fx_library.json',
  './data/hidden_particle_fx.json',
  './data/catalogo_idle_120.json',
  './data/catalogo_movimientos.json',
  './data/backgrounds_manifest.json',
  './data/runtime_manifest.json',
  './data/specials_registry.json',
  './data/offline_assets.json',
  './engine/pixi.min.js',
  './engine/pg_rng.js',
  './engine/pg_cinematics.js',
  './engine/pg_loader.js',
  './engine/pg_input.js',
  './engine/pg_sim.js',
  './engine/pg_ai.js',
  './engine/pg_training.js',
  './engine/pg_stage.js',
  './engine/pg_render.js',
  './engine/pg_touch.js',
  './engine/pg_store.js',
  './engine/pg_audio.js',
  './engine/pg_gamepad.js',
  './engine/pg_frontend.js',
  './engine/pg_game.js',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/audio/LEEME.txt',
  './assets/audio/intro_narration_es_mx.wav'
];

self.addEventListener('install', (event) => {
  const manifestUrl = new URL('./data/offline_assets.json', self.registration.scope);
  event.waitUntil(
    fetch(manifestUrl, { cache: 'reload' }).then((response) => {
      if (!response.ok) throw new Error('No se pudo leer data/offline_assets.json (' + response.status + ')');
      return response.json();
    }).then((offlineAssets) => {
      if (!Array.isArray(offlineAssets)) throw new TypeError('data/offline_assets.json debe ser una lista');
      const urls = Array.from(new Set(STATIC_ASSETS.concat(offlineAssets).map((path) =>
        new URL(path, self.registration.scope).href
      )));
      return caches.open(CACHE_NAME).then((cache) => cache.addAll(urls));
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      if (cached) {
        // En segundo plano revalidar desde la red si está disponible
        fetch(req).then((networkRes) => {
          if (networkRes && networkRes.status === 200) {
            caches.open(CACHE_NAME).then((cache) => cache.put(req, networkRes.clone()));
          }
        }).catch(() => {/* sin conexión activa; sirviendo desde caché */});
        return cached;
      }

      return fetch(req).then((networkRes) => {
        if (!networkRes || networkRes.status !== 200 || networkRes.type === 'opaque') {
          return networkRes;
        }
        const toCache = networkRes.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(req, toCache);
        });
        return networkRes;
      }).catch(() => {
        // Fallback sin conexión para navegación
        if (req.mode === 'navigate') {
          return caches.match('./game.html') || caches.match('./index.html');
        }
      });
    })
  );
});
