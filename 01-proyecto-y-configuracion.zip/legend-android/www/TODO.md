# TODO — Etapa 1: Demo Arcade sólida

- [x] **Campaña fija de cinco combates.** Arcade pide al protagonista y recorre Regente, Cadena, Calavera, Nadia y Garravas; cada combate conserva la campaña y muestra su progreso.
- [x] **Resultados con reintento y continuación.** Una victoria permite avanzar al siguiente combate; una derrota permite reintentar sin perder el índice de campaña; los demás modos permanecen separados.
- [x] **Jefe final reservado en Arcade.** Garravas aparece como quinto rival con dificultad 3, escenario del penal y etiqueta de jefe final; permanece seleccionable en Versus, Equipos y Torneo.
- [x] **Cierre narrativo básico y créditos.** Tras derrotar a Garravas se muestra una escena final separada con narrativa, créditos y regreso al menú.
- [x] **Audio placeholder de campaña.** Se añadieron cues procedurales de jefe y cierre, además de una pista de combate de jefe, sin introducir dependencia externa ni audio horneado en sprites.
- [x] **Auditoría de atlas Garravas/Mateo.** La revisión global cubre 26 personajes y 118 atlas; no hay frames usados vacíos, errores de mapeo ni errores dimensionales. El especial oculto de Mateo fue regenerado para eliminar residuos de celdas vecinas y normalizar sus anclas a 0.5/1.0; los FX siguen separados.
- [ ] **Balance con jugadores reales.** Ajustar dificultades, tiempos y daño después de sesiones manuales completas de cinco combates.
- [ ] **Audio definitivo y pruebas físicas.** Sustituir placeholders si procede, probar en Android físico y optimizar rendimiento de cargas, atlas y audio.
