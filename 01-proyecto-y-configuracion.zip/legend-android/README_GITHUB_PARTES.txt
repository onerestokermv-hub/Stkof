LEGEND OF PRESOS - PAQUETE PARA GITHUB
=====================================

Este proyecto se entrega dividido en ZIP para facilitar la carga.

RECONSTRUCCION:
1. Crea una carpeta vacia.
2. Extrae TODOS los ZIP en esa misma carpeta, conservando las rutas.
3. Debe quedar la carpeta legend-android/ con package.json, config.xml y www/.
4. Sube el contenido de legend-android/ al repositorio (no subas los ZIP como sustituto del codigo).

PLATAFORMA ANDROID:
La carpeta platforms/android/ se omite intencionalmente: Cordova la genera y contiene archivos de compilacion/intermedios que no conviene versionar.
Desde la carpeta legend-android ejecuta:
  npm ci
  npx cordova platform add android
  npx cordova build android

Requisitos de compilacion: Node.js compatible con el package-lock, Java 21, Android SDK y Gradle requeridos por la version instalada de Cordova Android.

IMPORTANTE:
- Extrae todos los paquetes en el mismo destino.
- No renombres las carpetas internas.
- No subas node_modules, platforms/android/build ni archivos locales de SDK.
