# Nina KOF — runtime sprite sheets v3

4 hojas de 480×480 px, 16 frames por hoja, celdas exactas de 120×120, RGBA real, pivote bottom-center, orientación derecha.
