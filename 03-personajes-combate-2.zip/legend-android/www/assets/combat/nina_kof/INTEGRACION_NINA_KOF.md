# Integración de atlas — Nina KOF

## Resultado del procesamiento

Las cuatro hojas originales de Nina se conservaron byte por byte. Sus manifiestos declaran 4×4 celdas de 120×120 px, RGBA con transparencia y pivote visual inferior-centro. Se procesaron sus 64 cuadros, además de los 12 cuadros de los borradores generados previamente (`run`, `front_grab`, `victory_pose`), mediante contornos de alpha.

`tools/process_nina_contours.py` ejecuta `cv2.findContours(RETR_EXTERNAL)` sobre `alpha > 0`, toma la unión de los rectángulos delimitadores y copia el recorte RGBA sin recolorear, escalar, eliminar componentes ni dibujar píxeles. Genera un atlas horizontal por grupo, mapa de coordenadas y anclas por cuadro para `PGLoader.loadGridCharacter`. El pivote usado para calcular cada ancla es (60,120) dentro de la celda original de 120×120, conforme a la declaración de pivote del manifiesto. La trazabilidad, SHA-256 y bounds por cuadro están en `processed_contours/nina_kof_contour_map.json`.

Las imágenes por contorno quedan en `processed_contours/frames/<grupo>/`; los atlas listos para corte del motor en `processed_contours/atlases/`; y los `coordsFile`/`anchorsFile` en `processed_contours/metadata/`. Las hojas originales y los atlas AI provisionales permanecen intactos.

## Mapeo de arte propuesto

Cada grupo fuente tiene cuatro cuadros en orden izquierda→derecha y se mapea a un nombre de clip que reconoce el motor. Esto es un mapeo de arte/estado, no define por sí mismo el timing ni la acción de combate.

| Grupo/etiqueta fuente | Cuadros fuente | Clip de arte candidato |
|---|---:|---|
| `idle` | base 0–3 | `idle` |
| `advance` | base 4–7 | `walk` |
| `jump` | base 8–11 | `jump_mobility` |
| `crouch` | base 12–15 | `crouch_guard` (postura; no es normal agachado) |
| `light_punch` | ataques 0–3 | `atk_light` |
| `heavy_punch` | ataques 4–7 | `atk_heavy` |
| `low_kick` | ataques 8–11 | **excluido** de runtime 1.0 por la decisión de no habilitar normales agachados |
| `high_kick` | ataques 12–15 | `atk_kick` |
| `hit` | reacciones 0–3 | `hurt` |
| `launch` | reacciones 4–7 | `damage_fall` |
| `fall` | reacciones 8–11 | `down` |
| `getup` | reacciones 12–15 | `recovery_pose` |
| `antler_charge` | especiales 0–3 | `atk_sp1` |
| `candy_star` | especiales 4–7 | `atk_sp2` |
| `ribbon_spin` | especiales 8–11 | `atk_sp3` |
| `festive_super` | especiales 12–15 | `atk_super` |
| `run` | atlas generado provisional 0–3 | `run` (borrador) |
| `front_grab` | atlas generado provisional 0–3 | `front_grab` (borrador; Nina aparece sola) |
| `victory_pose` | atlas generado provisional 0–3 | `victory_pose` (borrador) |

El archivo con la forma de atlas/clips para PGLoader es `nina_kof_contour_runtime_draft.char.json`. Sus 18 atlas contienen 72 cuadros de candidatos de clips; el cuarto grupo de ataque bajo queda archivado para referencia y no se precarga como clip runtime. Ningún FPS/hold se deduce del número de cuadros.

No hay grupos de frames fuente para `atk_airp` ni `atk_airk`; no se reutilizan las animaciones de pie para fingir golpes aéreos. Tampoco se activa un normal agachado ni CD.

## Verificación ejecutada

- `python3 tools/process_nina_contours.py`: 76 recortes, 19 grupos.
- `python3 tools/validate_nina_contours.py`: 76 recortes pixel-exactos contra las fuentes, hashes fuente intactos, bounds, mapas de atlas y pivotes validados; 18 candidatos runtime; `low_kick` excluido.
- `python3 qa/test_nina_contour_loader.py`: Chromium real cargó el borrador mediante `PGLoader.loadGridCharacter`: 18 clips, 72 texturas, 18 atlas, 0 errores de consola. Resultado guardado en `qa/nina_contour_loader_chromium.json`.

Esta prueba verifica la carga de los recortes y mapas de atlas por el loader real. **No** prueba que Nina aparezca en el selector ni que sus ataques conecten: el roster se mantiene en `status: "needs_data"`.

## Qué falta para hacerla seleccionable y jugable

El motor dibuja los clips, pero no se generaron movimientos de combate porque no existen datos autorizados de:

- `renderScale` aprobado y validación de encuadre/pivote en el juego;
- FPS, hold y orden temporal aprobado de cada clip;
- objetos `moves` e `inputs` completos, incluidos comandos de especiales y súper;
- startup/active/recovery, hitboxes, hitFrames, daño, stun, pushback, hitstop y cancelaciones;
- FX/audio aplicables a los golpes y prueba de contacto real;
- nombre visible/perfil y confirmación de las etiquetas fuente para movimientos.
- decisión o arte aprobado para los ataques aéreos que el resto del roster sí puede tener; Nina no los tiene en estas hojas.

No inferí estos valores desde el contorno o el número de cuadros, ni copié estadísticas de otro luchador. Para habilitarla habrá que completar `nina_kof.char.json` con los datos revisados (o trasladar allí `atlases`/`clips` del borrador), completar `moves` e `inputs`, ejecutar `python3 tools/validate_data.py`, probar combate por UI y recién entonces cambiar la entrada de `data/roster.json` a `status: "playable"`. Cambiar solo el estado del roster haría aparecer una definición incompleta y puede romper la partida.
